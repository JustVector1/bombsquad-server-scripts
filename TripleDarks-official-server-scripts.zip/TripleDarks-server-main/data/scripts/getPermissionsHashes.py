adminHashes = []
vipHashes = []
banlist = {}
topperslist = []
effectCustomers = {}
customlist = {}
ownerHashes = []
surroundingObjectEffect = []
sparkEffect = []
smokeEffect = []
scorchEffect = [] 
distortionEffect = []
glowEffect = []
iceEffect=[]
slimeEffect = []
metalEffect = []
dragonHashes = []
customtagHashes=[]

#donot change the order of the list
#to enable/disable commands and effects for top 5 players goto settings.py

