import bs
from datetime import datetime
date = datetime.now().strftime('%d')

enableTop5effects = True
enableTop5commands = False
enableCoinSystem = True
nightMode = True

animateOnPwps = True
shieldOnPwps = True
discoLightOnPwps = False
nameOnPwps = True

nameOnBombs = True
shieldOnBombs = True
lightsOnBombs = False

enableStats = True

print 'Enable Stats: ', enableStats

enableChatFilter = True

spamProtection = True

coinTexts = ['swipe bomb to jumb to perform backflip']

questionDelay = 120 #60 #seconds
questionsList = {'Who is the owner of this server?': 'vector', 'Who is the editor of this server?': 'vector', 'In which language bombsquad is coded?' : 'python', 'How many owners in this server?' : '3','What is the name of powerup do pro players hate?' : 'shield','Do you like this server?':'yes','What is the year was bombsquad release?':'2011',
       'add': None, 
       'multiply': None}

availableCommands = {'/nv': 50,  
   '/box': 30, 
   '/boxall': 60, 
   '/spaz': 50, 
   '/spazall': 100, 
   '/inv': 40, 
   '/invall': 80, 
   '/tex': 20, 
   '/texall': 40, 
   '/freeze': 60, 
   '/freezeall': 100, 
   '/sleep': 40, 
   '/sleepall': 80, 
   '/thaw': 50, 
   '/thawall': 70, 
   '/kill': 80, 
   '/killall': 150, 
   '/end': 100, 
   '/hug': 60, 
   '/hugall': 100, 
   '/tint': 90, 
   '/sm': 50, 
   '/fly': 50, 
   '/flyall': 100, 
   '/heal': 50, 
   '/healall': 70}

availableEffects = {'ice': 50, 
   'sweat': 75, 
   'scorch': 80, 
   'glow': 100, 
   'distortion': 120, 
   'slime': 130, 
   'metal': 150, 
   'surrounder': 250}
