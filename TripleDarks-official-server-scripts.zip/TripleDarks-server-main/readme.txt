Hello I'm VECTOR
I want to shere my scripts of triple darks server with everyone

Create By nr.official
#########################
Scripts edited by: VECTOR
Please give me some credit in your server:)
Thanks to my best friends: Derzk | Revix | Prism
Enjoy!